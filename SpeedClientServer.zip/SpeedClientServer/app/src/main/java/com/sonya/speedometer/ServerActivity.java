package com.sonya.speedometer;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.ComponentName;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.ServiceConnection;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.IBinder;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ServerActivity extends AppCompatActivity {


    static boolean status;
    LocationManager locationManager;
    static TextView dist, time, speed, acceleration, threshold;
    Button brake;
    ImageView image;
    static ProgressDialog locate;
    static int p = 0;


    @Override
    public void onBackPressed() {
        if (status == false)
            super.onBackPressed();
        else
            moveTaskToBack(true);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_server);
        dist = (TextView) findViewById(R.id.distancetext_s);
        time = (TextView) findViewById(R.id.timetext_s);
        speed = (TextView) findViewById(R.id.speedtext_s);
        threshold = (TextView) findViewById(R.id.threshold_s);
        acceleration = (TextView) findViewById(R.id.accelerationtext_s);
        brake = (Button) findViewById(R.id.brake);

        image = (ImageView) findViewById(R.id.image);
        brake.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // write to DB to tell client to brake
            }
        });

    }
}